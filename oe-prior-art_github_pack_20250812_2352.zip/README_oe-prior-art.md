# oe-prior-art — Oblion.E / OE (White Paper & preuve publique)

Ce dépôt **oe-prior-art** publie le white paper du projet **OE** (Oblion.E) et sert de **trace publique** (antériorité).

## Fichiers
- **Whitepaper (PDF)** : `Whitepaper_OE_OblionE_FR_v1.2_gibbs.pdf`
- **Whitepaper (DOCX)** : `Whitepaper_OE_OblionE_FR_v1.2_gibbs.docx`
- *(Optionnel)* **Note d’antériorité** : `OblionE_OE_Note_d_Anteriorite_...pdf` + `..._hashes_...txt`

## Intégrité (SHA-256)
```
8eff8d95d7c9c05be7fc2a7a3eaee874583c158a7fada0dbfae6ce627963d31f  Whitepaper_OE_OblionE_FR_v1.2_gibbs.pdf
```

## Contact
Oblion.E — **gibbs**  
Email : **oblion.oblion.e@gmail.com**

---
© 2025 Oblion.E — Document informatif (pas une offre de titres).
